package com.example.teste_android

class Mensagem(var mensagem: String) {
}
